# Paper 1 Reproducible Pipeline -- Stage 01 Label Ontology Report

This table is the single source of truth for wfdb-annotation-symbol to Paper 1 protocol class (UC/FM/IN) mapping. It is new relative to the old pipeline, which left this mapping implicit -- see Paper1/MIGRATION_PLAN.md Section 5.

## Ontology table

| wfdb_symbol | normalized_event_type | class_label | in_primary_protocol | exclusion_reason |
|---|---|---|---|---|
| `C` | contraction | UC | True | -- |
| `(c)` | possible_contraction | -- | False | ambiguous/weak annotation; not part of the fixed UC/FM/IN protocol |
| `fm` | fetal_movement | FM | True | -- |
| `pm` | participant_movement | -- | False | movement-artifact marker, not an analysis class |
| `em` | equipment_manipulation | -- | False | equipment-artifact marker, not an analysis class |
| `pos` | position_change | -- | False | position-change marker, not an analysis class |
| `*(none -- baseline)*` | baseline | IN | True | -- |
| `<mixed window>` | mixed | -- | False | window contains a competing-class annotation; not a clean single-class unit |

## Symbol coverage check

- **PASS**: every distinct wfdb_symbol in `annotation_events.csv` (6 distinct symbols) has an ontology row.

## Class distribution (annotation-anchored events only; excludes synthetic baseline/mixed rows)

- FM: 463
- UC: 398

## Downstream usage

- Stage 02 (`02_windowing.py`) uses this table to decide which annotation types anchor event windows (`in_primary_protocol == True` types, plus `possible_contraction` and movement/equipment/position markers still contribute to guard intervals and purity checks per the original Module 1 windowing rules).
- Stage 06 (`06_mixed_models.py`) uses this table to confirm no non-protocol class (`possible_contraction`, `mixed`) leaks into the confirmatory UC/FM/IN analysis.
