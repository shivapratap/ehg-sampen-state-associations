# Paper 1 Reproducible Pipeline -- Stage 05 Feature QC Report

**Overall QC outcome: PASS**

Channels checked: EHG9, EHG10, EHG11, EHG12
Canonical long-format table: 17132 rows (112 recordings x 4 channels).

## 1. Row-count parity (window_id sets identical across channels)

| channel   |   n_rows |   n_unique_window_ids | matches_reference_window_id_set   | reference_channel   |   missing_vs_reference |   extra_vs_reference |
|:----------|---------:|----------------------:|:----------------------------------|:--------------------|-----------------------:|---------------------:|
| EHG9      |     4283 |                  4283 | True                              | EHG9                |                      0 |                    0 |
| EHG10     |     4283 |                  4283 | True                              | EHG9                |                      0 |                    0 |
| EHG11     |     4283 |                  4283 | True                              | EHG9                |                      0 |                    0 |
| EHG12     |     4283 |                  4283 | True                              | EHG9                |                      0 |                    0 |

**PASS** -- all channels share an identical window_id set.

## 2. Duplicate (window_id, channel) detection

**PASS** -- no duplicate (window_id, channel) pairs found in any channel.

## 3. Sample-count integrity vs. manifest

- **EHG9**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG10**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG11**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG12**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.

## 4. Feature-column-set drift vs. config.FEATURE_COLUMNS (87 columns)

- **EHG9**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG10**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG11**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG12**: PASS -- all 87 registry columns present, no unexpected feature-like columns.

## 5. Missingness summary

- **EHG9**: 0 total NaN cells across 87 feature columns (0 in fragile-feature columns).
- **EHG10**: 0 total NaN cells across 87 feature columns (0 in fragile-feature columns).
- **EHG11**: 0 total NaN cells across 87 feature columns (0 in fragile-feature columns).
- **EHG12**: 0 total NaN cells across 87 feature columns (0 in fragile-feature columns).

**PASS** -- zero missingness across all channels and feature columns.
