# Stage 05 -- Sample-count integrity & feature-column-set drift

## Sample-count integrity

- **EHG9**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG10**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG11**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.
- **EHG12**: PASS -- all 4283 rows have `filtered_sample_count == 1200`.

## Feature-column-set drift

- **EHG9**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG10**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG11**: PASS -- all 87 registry columns present, no unexpected feature-like columns.
- **EHG12**: PASS -- all 87 registry columns present, no unexpected feature-like columns.