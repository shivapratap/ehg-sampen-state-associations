# Paper 1 Reproducible Pipeline -- Stage 00 Cohort Summary

All counts below are computed from the raw dataset by this run -- none are hardcoded.

- Recordings listed in RECORDS manifest: 123
- Recordings with a local .hea file: 123
- Recordings with a local .dat file: 123
- Recordings with a local .atr (annotation) file: 112
- Recordings with a local .jpg (tocograph scan): 123
- Patients (parsed from recording IDs): 45 (expected 45, delta 0)

## Local files vs. PhysioNet's published project-page text

- Published doc states 122 recordings; local RECORDS/.hea count is 123 (delta +1).
- Published doc states 111 annotated recordings; local .atr count is 112 (delta +1).

## QC severity distribution

- info: 123
- warning: 0
- error: 0
- fatal: 0

## Recommended-action distribution

- retain: 123
- inspect: 0
- quarantine: 0

## Annotation symbol counts (raw, across all recordings)

- `fm`: 463
- `C`: 398
- `(c)`: 71
- `pm`: 63
- `em`: 45
- `pos`: 8

## Reproducibility note

This stage's EHG9-relevant outputs (recording_inventory.csv, channel_mapping.csv, annotation_events.csv) are validated against the frozen pipeline/module0/outputs/ files by the reproducibility gate before Stage 01 onward is trusted. See results/paper1/validation/.
