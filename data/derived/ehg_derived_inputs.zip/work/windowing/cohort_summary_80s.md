# Paper 1 Reproducible Pipeline -- Stage 02 Cohort Summary

Recordings active: 123 (skipped by Stage 00 QC: 0).
Recordings with no annotation file, excluded from baseline generation by default (flagged, not silently decided): 11.

All counts below are computed from this run's manifest -- none are hand-typed.

## Window size: 80s (PRIMARY -- fixed protocol; only size built by this stage)

- `baseline`: 2470
- `fetal_movement`: 382
- `contraction`: 328
- `mixed`: 145
- `possible_contraction`: 66
- baseline windows flagged `tight_clearance`: 498
- distinct patients contributing at least one window: 42

## Ontology consistency check

- **PASS**: every window_class value in the manifest has a Stage 01 ontology row.

## Reproducibility note

This stage's window_manifest_60s.csv is validated against the frozen pipeline/module1/outputs/window_manifest_60s.csv by the reproducibility gate before Stage 03 onward is trusted. See results/paper1/validation/.
